export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Internship';
  description: string;
  requirements: string[];
  salary: string;
  postedDate: string;
  imageUrl: string;
}

export type Country = 'USA' | 'UK' | 'Canada' | 'Australia' | 'Germany' | 'Japan' | 'Singapore';