import { Job } from './types';

export const jobs: Job[] = [
  {
    id: '1',
    title: 'Software Engineering Intern',
    company: 'Tech Global Solutions',
    location: 'San Francisco, USA',
    type: 'Internship',
    description: 'Join our dynamic team developing cutting-edge software solutions. Work with the latest technologies and learn from experienced mentors.',
    requirements: ['Currently pursuing CS degree', 'JavaScript/TypeScript knowledge', 'Strong problem-solving skills'],
    salary: '$6000-8000/month',
    postedDate: '2024-03-15',
    imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=500'
  },
  {
    id: '2',
    title: 'Data Science Graduate Program',
    company: 'Analytics Pro',
    location: 'London, UK',
    type: 'Full-time',
    description: 'Two-year graduate program focusing on machine learning and data analytics. Rotation across different departments.',
    requirements: ['Masters in Data Science/Statistics', 'Python/R proficiency', 'Strong analytical skills'],
    salary: '£45,000/year',
    postedDate: '2024-03-14',
    imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=500'
  },
  {
    id: '3',
    title: 'Marketing Assistant',
    company: 'Global Brands Inc',
    location: 'Toronto, Canada',
    type: 'Part-time',
    description: 'Support our marketing team in campaign planning and execution. Perfect for students interested in international marketing.',
    requirements: ['Marketing or Business major', 'Creative mindset', 'Social media expertise'],
    salary: 'CAD 25/hour',
    postedDate: '2024-03-13',
    imageUrl: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&q=80&w=500'
  }
];