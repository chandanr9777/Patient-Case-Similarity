import React from 'react';
import { Country } from '../types';

interface FiltersProps {
  selectedCountry: Country | null;
  onCountryChange: (country: Country | null) => void;
  onTypeChange: (type: string | null) => void;
}

export function Filters({ selectedCountry, onCountryChange, onTypeChange }: FiltersProps) {
  const countries: Country[] = ['USA', 'UK', 'Canada', 'Australia', 'Germany', 'Japan', 'Singapore'];
  const jobTypes = ['Full-time', 'Part-time', 'Internship'];

  return (
    <div className="flex flex-col space-y-4 p-4 bg-white rounded-lg shadow-sm">
      <div>
        <h3 className="text-lg font-semibold mb-2">Location</h3>
        <select
          className="w-full p-2 border border-gray-300 rounded-md"
          onChange={(e) => onCountryChange(e.target.value as Country)}
          value={selectedCountry || ''}
        >
          <option value="">All Countries</option>
          {countries.map((country) => (
            <option key={country} value={country}>
              {country}
            </option>
          ))}
        </select>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">Job Type</h3>
        <div className="space-y-2">
          {jobTypes.map((type) => (
            <label key={type} className="flex items-center space-x-2">
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-blue-600"
                onChange={(e) => onTypeChange(e.target.checked ? type : null)}
              />
              <span>{type}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}